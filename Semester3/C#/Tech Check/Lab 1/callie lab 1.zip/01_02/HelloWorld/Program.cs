﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = Console.ReadLine();
            Console.WriteLine(a);
        }
    }
}
